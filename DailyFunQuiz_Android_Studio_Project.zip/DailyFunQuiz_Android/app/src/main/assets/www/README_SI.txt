Daily Fun Quiz - Sinhala / English (Updated)

මෙය phone එකෙන් browser එක හරහා ක්‍රීඩා කළ හැකි Quiz Game එකකි.
- English සහ සිංහල ප්‍රශ්න 100ක්
- එක් වටයකට අහඹු ලෙස ප්‍රශ්න 10ක්
- තේරීම් 4ක් සහ නිවැරදි පිළිතුරට ලකුණු 1ක්
- එක් ප්‍රශ්නයකට තත්පර 30ක කාල සීමාව
- Sinhala / English මාරු කිරීම
- Skip, Restart සහ Play again
- PWA offline cache update කර ඇත

Netlify වෙත යාවත්කාලීන version එක upload කිරීම:
1. ZIP එක phone එකෙන් Extract කරන්න.
2. Extract වූ folder එක ඇතුළට යන්න. index.html, manifest.webmanifest, sw.js සහ icons folder එක එකම තැන තිබිය යුතුයි.
3. Netlify site එකේ Deploys / manual deploy (Netlify Drop) තෝරන්න.
4. ඒ files තියෙන extracted folder එක upload කරන්න. ZIP එක ඇතුළත folder එකක් තවත් folder එකක් ලෙස නොතබා, index.html ඉහළම මට්ටමේ තිබිය යුතුයි.
5. Deploy අවසන් වූ පසු site එක browser එකේ නැවත විවෘත කර refresh කරන්න. පරණ version එක පෙනේ නම් browser cache clear කර නැවත විවෘත කරන්න.

සටහන: මෙය PWA/web game එකක්. APK එකක් හෝ Play Store app එකක් නොවේ. මේ version එකට AdMob/AdSense ads සම්බන්ධ කරලා නැහැ. ආදායම සඳහා සුදුසු ad platform approval සහ නිවැරදි integration අවශ්‍යයි; ආදායම සහතික නැහැ.
