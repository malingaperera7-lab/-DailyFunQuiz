Daily Fun Quiz - Android Studio Project

මෙය ඔබගේ Daily Fun Quiz Learning Hub වෙබ්/PWA ගොනුව Android WebView App එකක් ලෙස පෙන්වන Android Studio project එකකි.
ප්‍රශ්න/පිළිතුරු සහ Learning Hub පිටු app එක තුළම offline assets ලෙස ඇතුළත් කර ඇත.

Android App (APK/AAB) සෑදීමට:
1. ZIP එක Extract කරන්න.
2. පරිගණකයක Android Studio install කර Open තෝරන්න.
3. Extract කළ DailyFunQuiz_Android folder එක තෝරන්න.
4. Gradle Sync අවසන් වනතුරු internet සම්බන්ධතාවය තබාගන්න.
5. පරීක්ෂා කිරීමට Run ඔබන්න.
6. Play Store සඳහා Build > Generate Signed Bundle / APK > Android App Bundle තෝරන්න.
7. නව keystore එකක් සාදා එය ආරක්ෂිතව backup කරගන්න. Password අමතක නොකරන්න.

වැදගත්:
- මෙය Android Studio source project එකකි; සූදානම් APK/AAB ගොනුවක් නොවේ.
- මේ version එකට AdMob එකතු කර නැත. AdMob account එක සහ App ID/Ad Unit ID අවශ්‍ය නිසා ඒවා නොමැතිව ads සක්‍රීය කර නැත.
- Play Store වෙත publish කිරීමට පෙර privacy policy, Data safety, content rating, app icon, screenshots සහ Google Play Console අවශ්‍යතා පරීක්ෂා කළ යුතුය.
- Package ID: com.dailyfunquiz.learninghub
- Version: 1.0 (versionCode 1)
